# TeamTrack — Weekly Task Intelligence Platform
### Project Plan · HLD · LLD

---

## Project Overview

TeamTrack is a full-stack team productivity platform that allows team members to log their weekly tasks with time tracking, blockers, descriptions, and evidence attachments. Managers get a dedicated portal to review submissions, add threaded comments (approvals/doubts/feedback), and download quarterly work analysis reports.

**Tech Stack:** Java 17 · Spring Boot 3.x · React.js (Vite + Tailwind CSS) · MongoDB Atlas · AWS

---

## Resume Heading & Description

**TeamTrack — Weekly Task Tracker & Work Analysis Platform**
`Java · Spring Boot 3 · React.js · MongoDB · AWS`

> Built a full-stack team productivity platform on AWS. Backend runs as Dockerised Spring Boot 3 microservices on Amazon EKS (ap-south-1) behind an ALB, with JWT-based RBAC via Spring Security. Team members log weekly tasks with hours, blockers, and evidence attachments stored on S3 via pre-signed URLs. Managers review submissions, add threaded comments (approvals/doubts), and download quarterly work analysis reports (PDF/XLSX) generated server-side and delivered from S3. Notifications sent via AWS SES. CI/CD pipeline via AWS CodePipeline + CodeBuild, Docker images in ECR, secrets managed through AWS Secrets Manager. Frontend hosted on S3 + CloudFront.

---

## High-Level Design (HLD)

### Architecture Overview

```
Users (Browser / Mobile)
        │  HTTPS
        ▼
AWS CloudFront CDN
        │
        ▼
AWS S3 (React.js static build)
        │  REST / HTTPS
        ▼
AWS Application Load Balancer (ALB)
        │
        ▼
┌─────────────────────────────────────────────────┐
│         AWS VPC — ap-south-1                    │
│  ┌──────────────────────────────────────────┐   │
│  │  Public Subnet                           │   │
│  │  ALB · Internet Gateway                  │   │
│  └──────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────┐   │
│  │  Private Subnet — EKS Cluster            │   │
│  │  Task Pod | Comment Pod | User Pod |     │   │
│  │  Report Pod  (Spring Boot, HPA enabled)  │   │
│  └──────────────────────────────────────────┘   │
│  NAT Gateway (outbound to AWS services)          │
└─────────────────────────────────────────────────┘
        │               │              │
        ▼               ▼              ▼
MongoDB Atlas       AWS S3         AWS SES
(VPC Peering)   (Attachments,   (Email Alerts)
                  Reports)
```

### AWS Service Mapping

| Layer | AWS Service | Purpose |
|---|---|---|
| Frontend hosting | S3 + CloudFront | Static React build served via CDN |
| Container orchestration | AWS EKS (ap-south-1) | Spring Boot pod management, HPA auto-scaling |
| Load balancing | AWS ALB | Routes HTTPS traffic to EKS ingress |
| File storage | AWS S3 + Pre-signed URLs | Attachments upload, quarterly report exports |
| Database | MongoDB Atlas (AWS ap-south-1) | VPC peering / PrivateLink with EKS |
| Email notifications | AWS SES | Comment and approval email alerts |
| Auth (optional enhancement) | AWS Cognito | User pool for advanced IAM |
| Secrets management | AWS Secrets Manager | DB credentials, JWT secret, SES keys |
| Container registry | AWS ECR | Docker image storage for EKS deployments |
| CI/CD | AWS CodePipeline + CodeBuild | Build → push to ECR → deploy to EKS |
| Real-time (optional) | AWS API Gateway WebSocket | Live comment push notifications |
| Networking | AWS VPC | Public subnet (ALB), private subnet (EKS pods) |

### User Roles

| Role | Key Permissions |
|---|---|
| `TEAM_MEMBER` | Create/edit own tasks, view own weeks, view manager comments, resolve comments |
| `MANAGER` | View all members' tasks, add comments (APPROVAL/DOUBT/FEEDBACK), approve weeks, download quarterly reports |

---

## Low-Level Design (LLD)

### MongoDB Collections & Schema

#### `users`
```json
{
  "_id": "ObjectId",
  "name": "string",
  "email": "string (unique)",
  "passwordHash": "string",
  "role": "TEAM_MEMBER | MANAGER",
  "teamId": "string",
  "createdAt": "timestamp"
}
```

#### `weeks`
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId (ref: users)",
  "weekLabel": "string (e.g. Week 21, 2026)",
  "startDate": "date",
  "endDate": "date",
  "status": "DRAFT | SUBMITTED | APPROVED",
  "createdAt": "timestamp",
  "updatedAt": "timestamp"
}
```

#### `tasks`
```json
{
  "_id": "ObjectId",
  "weekId": "ObjectId (ref: weeks)",
  "userId": "ObjectId (ref: users)",
  "title": "string",
  "description": "string",
  "status": "TODO | IN_PROGRESS | COMPLETED | BLOCKED",
  "hoursSpent": "int",
  "blocker": "string (nullable)",
  "evidenceLinks": ["url1", "url2"],
  "attachmentUrls": ["s3-signed-url1"],
  "completedAt": "timestamp (nullable)",
  "createdAt": "timestamp",
  "updatedAt": "timestamp"
}
```

#### `comments`
```json
{
  "_id": "ObjectId",
  "taskId": "ObjectId (ref: tasks)",
  "authorId": "ObjectId (ref: users)",
  "body": "string",
  "type": "APPROVAL | DOUBT | FEEDBACK",
  "resolved": "boolean (default: false)",
  "resolvedById": "ObjectId (nullable, ref: users)",
  "createdAt": "timestamp"
}
```

#### `reports`
```json
{
  "_id": "ObjectId",
  "managerId": "ObjectId (ref: users)",
  "teamId": "string",
  "quarter": "Q1 | Q2 | Q3 | Q4",
  "year": "int",
  "format": "PDF | XLSX",
  "s3Url": "string (pre-signed download URL)",
  "generatedAt": "timestamp"
}
```

### MongoDB Indexes

```javascript
// tasks — most frequent query pattern
db.tasks.createIndex({ weekId: 1, userId: 1 })
db.tasks.createIndex({ userId: 1, createdAt: -1 })

// weeks — status filter + member lookup
db.weeks.createIndex({ userId: 1, status: 1 })
db.weeks.createIndex({ startDate: 1, endDate: 1 })

// comments — per task thread
db.comments.createIndex({ taskId: 1, createdAt: 1 })
db.comments.createIndex({ taskId: 1, resolved: 1 })
```

---

### REST API Design

**Base URL:** `/api/v1`

#### Auth Endpoints

| Method | Path | Role | Description |
|---|---|---|---|
| `POST` | `/auth/register` | Public | Register new user |
| `POST` | `/auth/login` | Public | Login, returns JWT |
| `GET` | `/auth/me` | Any | Get current user profile |

#### Task Endpoints

| Method | Path | Role | Description |
|---|---|---|---|
| `POST` | `/tasks` | TEAM_MEMBER | Create a new task |
| `GET` | `/tasks?weekId=` | TEAM_MEMBER | Get tasks for a week |
| `PUT` | `/tasks/{id}` | TEAM_MEMBER | Update task |
| `DELETE` | `/tasks/{id}` | TEAM_MEMBER | Delete task (DRAFT week only) |
| `POST` | `/tasks/{id}/attachments` | TEAM_MEMBER | Get S3 pre-signed URL for upload |

#### Week Endpoints

| Method | Path | Role | Description |
|---|---|---|---|
| `POST` | `/weeks` | TEAM_MEMBER | Create a new week |
| `GET` | `/weeks/my` | TEAM_MEMBER | Get own weeks list |
| `PUT` | `/weeks/{id}/submit` | TEAM_MEMBER | Submit week for review |
| `GET` | `/manager/weeks?userId=&status=` | MANAGER | Browse all members' weeks |
| `PUT` | `/manager/weeks/{id}/approve` | MANAGER | Approve a submitted week |

#### Comment Endpoints

| Method | Path | Role | Description |
|---|---|---|---|
| `POST` | `/comments` | MANAGER | Add comment to a task |
| `GET` | `/comments?taskId=` | Any | Get comments for a task |
| `PUT` | `/comments/{id}/resolve` | TEAM_MEMBER | Resolve a comment |

#### Report Endpoints

| Method | Path | Role | Description |
|---|---|---|---|
| `POST` | `/manager/reports/generate` | MANAGER | Trigger quarterly report generation |
| `GET` | `/manager/reports` | MANAGER | List previously generated reports |
| `GET` | `/manager/reports/{id}/download` | MANAGER | Get S3 pre-signed download URL |

---

### Spring Boot Service Architecture

```
com.teamtrack
├── config/
│   ├── SecurityConfig.java          // JWT filter, RBAC rules
│   ├── S3Config.java                // AmazonS3 bean (AWS SDK v2)
│   └── MongoConfig.java             // MongoDB indexes on startup
│
├── auth/
│   ├── AuthController.java
│   ├── AuthService.java
│   ├── JwtUtil.java
│   └── JwtAuthFilter.java          // OncePerRequestFilter
│
├── task/
│   ├── TaskController.java
│   ├── TaskService.java
│   └── TaskRepository.java         // MongoRepository<Task, String>
│
├── week/
│   ├── WeekController.java
│   ├── WeekService.java
│   └── WeekRepository.java
│
├── comment/
│   ├── CommentController.java
│   ├── CommentService.java
│   └── CommentRepository.java
│
├── report/
│   ├── ReportController.java
│   ├── ReportService.java          // Apache POI → PDF/XLSX → S3 upload
│   └── ReportRepository.java
│
├── notification/
│   └── EmailService.java           // AWS SES via JavaMailSender
│
├── storage/
│   └── S3StorageService.java       // Pre-signed URL generation
│
└── model/
    ├── User.java
    ├── Week.java
    ├── Task.java
    ├── Comment.java
    └── Report.java
```

### Security Configuration

```java
// Role-based URL access rules (Spring Security 6)
http
  .authorizeHttpRequests(auth -> auth
    .requestMatchers("/api/v1/auth/**").permitAll()
    .requestMatchers("/api/v1/manager/**").hasRole("MANAGER")
    .requestMatchers("/api/v1/**").hasAnyRole("TEAM_MEMBER", "MANAGER")
    .anyRequest().authenticated()
  )
  .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);
```

### S3 Pre-Signed URL Flow

```
Team Member → POST /tasks/{id}/attachments
           ← Spring Boot generates S3 pre-signed PUT URL (15 min expiry)
Team Member → PUT directly to S3 (no file bytes via Spring Boot)
           → Spring Boot stores S3 object key in task.attachmentUrls[]
```

### Report Generation Flow

```
Manager → POST /manager/reports/generate { quarter, year, teamId, format }
        → Report Service queries MongoDB aggregation pipeline
        → Apache POI generates PDF or XLSX in memory
        → S3StorageService uploads to s3://teamtrack-reports/{teamId}/{quarter}-{year}.pdf
        → Pre-signed GET URL (7-day expiry) returned in response
        → Report document saved to reports collection
```

---

## Task Lifecycle State Machine

```
DRAFT ──submit──▶ SUBMITTED ──approve──▶ APPROVED
  ▲                    │
  │                    │ (manager adds DOUBT/FEEDBACK comment)
  │                    ▼
  │              Member views comment
  │              Member resolves comment
  │                    │
  └──── week stays SUBMITTED until manager approves ────┘
```

**Comment types:**
- `APPROVAL` — manager explicitly approves a specific task
- `DOUBT` — manager has a question; member must resolve before week can be considered done
- `FEEDBACK` — informational note; no blocking resolution required

---

## CI/CD Pipeline (AWS CodePipeline)

```
GitHub (main branch push)
        │
        ▼
AWS CodePipeline Source Stage
        │
        ▼
AWS CodeBuild
  ├── mvn clean package -DskipTests
  ├── docker build -t teamtrack-backend .
  ├── docker push → AWS ECR
  └── npm run build → sync to S3 (frontend)
        │
        ▼
Deploy Stage
  └── kubectl apply -f k8s/ (EKS rolling update)
```

**Kubernetes manifests (`k8s/`):**
- `deployment.yaml` — Spring Boot pods, resource limits, env from Secrets Manager
- `service.yaml` — ClusterIP service per pod group
- `ingress.yaml` — ALB Ingress Controller (annotations for HTTPS, target-type: ip)
- `hpa.yaml` — HorizontalPodAutoscaler (CPU 70% threshold, min 2 / max 6 pods)

---

## Project Phases

### Phase 1 — Foundation (Week 1–2)
- Spring Boot 3 project scaffold (Maven, Java 17)
- React + Vite + Tailwind scaffold
- MongoDB Atlas cluster on AWS `ap-south-1`, VPC peering with EKS
- JWT auth: register, login, `/auth/me`
- AWS Secrets Manager: DB URI, JWT secret
- ECR repository created; local Docker build working

### Phase 2 — Core Features (Week 3–4)
- `Task`, `Week` CRUD APIs with full validation
- Weekly submission flow: `DRAFT → SUBMITTED`
- AWS S3 bucket + pre-signed URL endpoint for file upload
- Team member UI: task creation form, weekly dashboard, status indicators
- Evidence link + file attachment support

### Phase 3 — Manager Portal (Week 5–6)
- Manager dashboard: view all members, filter by week / member / status
- Comment API: `APPROVAL | DOUBT | FEEDBACK` types
- Member side: view comments, reply, resolve (`comment.resolved = true`)
- `SUBMITTED → APPROVED` week transition
- AWS SES email notifications on submission and new comment events

### Phase 4 — Reports, CI/CD & Polish (Week 7–8)
- Quarterly report service: MongoDB aggregation → Apache POI → PDF/XLSX → S3 upload
- Report download via pre-signed S3 URL
- AWS CodePipeline + CodeBuild CI/CD setup
- ALB Ingress Controller on EKS; HPA configuration
- UI polish, pagination, search/filter on manager dashboard
- Optional: AWS API Gateway WebSocket for real-time comment notifications

---

## Technology Versions

| Technology | Version |
|---|---|
| Java | 17 (LTS) |
| Spring Boot | 3.x |
| Spring Security | 6.x |
| MongoDB Driver | 4.x |
| React | 18.x |
| Vite | 5.x |
| Tailwind CSS | 3.x |
| AWS SDK | v2 (software.amazon.awssdk) |
| Apache POI | 5.x (report generation) |
| Docker | 24.x |
| Kubernetes | 1.29+ (EKS managed) |

---

*Plan version: 1.0 | Stack: Java · Spring Boot 3 · React.js · MongoDB · AWS*
